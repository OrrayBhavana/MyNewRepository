package com.cg.lab14;

import java.util.Scanner;
import java.util.function.BiFunction;

public class LambdaPowerDemo {
	public static void main(String args[])
	{
		PowerFunc pf= (x,y) -> Math.pow(x,y);
		Scanner sc=new Scanner(System.in);
		double x,y;
		System.out.println("Enter x value");
		x=sc.nextDouble();
		System.out.println("Enter y value");
		y=sc.nextDouble();
		double res=pf.powerVal(x,y);
		System.out.println("Power using lambda expression is "+res);
		BiFunction<Double,Double,Double> bi=(a,b) ->Math.pow(x,y);
		System.out.println("Using Bi function:"+bi.apply(x,y));
	}
}
