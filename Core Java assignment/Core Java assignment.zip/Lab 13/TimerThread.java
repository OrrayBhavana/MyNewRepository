package solutions13;

import java.util.*;

public class TimerThread implements Runnable
{

	public static void main(String[] args) 
	{
		//Task t1 = new Task("task1");
		Timer t = new Timer();
		//t.schedule(task,10000);
	}

	public void run() 
	{
		
	}

}
