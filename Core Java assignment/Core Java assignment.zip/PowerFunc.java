package com.cg.lab14;

public interface PowerFunc {
 public double powerVal(double x,double y);
}
